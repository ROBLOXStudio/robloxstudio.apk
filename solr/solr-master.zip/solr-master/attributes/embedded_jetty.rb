include_attribute 'solr::default'

default['jetty']['port'] = '8983'
