#
# Cookbook Name:: timezone
# Attribute:: default
#
# Copyright 2010, James Harton <james@sociable.co.nz>
#
# Apache 2.0 License.
#

default[:tz] = 'UTC'
