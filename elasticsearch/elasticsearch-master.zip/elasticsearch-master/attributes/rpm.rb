default.elasticsearch[:rpm_url] = "https://download.elasticsearch.org/elasticsearch/elasticsearch/elasticsearch-0.90.12.noarch.rpm"
default.elasticsearch[:rpm_sha] = "ab7ea2e00d8f1b73642e3ea44d9647b11e6b0b96"
