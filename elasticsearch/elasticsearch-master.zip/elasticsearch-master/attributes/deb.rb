default.elasticsearch[:deb_url] = "https://download.elasticsearch.org/elasticsearch/elasticsearch/elasticsearch-0.90.12.deb"
default.elasticsearch[:deb_sha] = "13783b95b35e347a3471f22234c544ae50655b78"
