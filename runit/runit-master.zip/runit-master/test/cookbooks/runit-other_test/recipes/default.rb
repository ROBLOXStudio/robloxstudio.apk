# Empty recipe for test-kitchen
