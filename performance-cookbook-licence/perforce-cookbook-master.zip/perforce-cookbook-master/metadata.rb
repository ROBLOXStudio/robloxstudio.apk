maintainer       "Josiah Kiehl"
maintainer_email "josiah@bluepojo.com"
license          "All rights reserved"
description      "Installs/Configures perforce"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.5"

supports         "mac_os_x"
name "perforce"
