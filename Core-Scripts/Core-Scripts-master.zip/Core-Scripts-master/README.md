Core-Scripts
============

All of ROBLOX's core client scripts.

These scripts are responsible for character & camera control, as well as in-game UI and other things.
